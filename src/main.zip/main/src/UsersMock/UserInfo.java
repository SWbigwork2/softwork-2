package UsersMock;

public interface UserInfo {
	 public String getId();
	 public String getName();
	 public String getPassword();
	 public UserType getRole();
	 public String getHotel();
}
