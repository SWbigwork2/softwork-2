package PromotionsMock;

public enum ResultMessage {
	   Success,Failure,hasexistpromotion
	}

