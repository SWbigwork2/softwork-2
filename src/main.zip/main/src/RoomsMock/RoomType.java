package RoomsMock;

public enum RoomType {
	big,small

}
