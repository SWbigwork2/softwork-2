package OrdersMock;

public enum OrderType {
	normal,revoke,done,error,all

}
