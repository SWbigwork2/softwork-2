package OrdersMock;

import HotelsMock.HotelPO;
import HotelsMock.HotelRanking;
import HotelsMock.HotelTradeArea;

public class HotelsInfo extends HotelPO{

	public HotelsInfo(String n, String a, HotelTradeArea t, String i, String s, HotelRanking r) {
		super(n, a, t, i, s, r);
		// TODO Auto-generated constructor stub
	}

}
