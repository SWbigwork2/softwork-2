package EvaluateMock;

import HotelsMock.HotelPO;
import HotelsMock.HotelRanking;
import HotelsMock.HotelTradeArea;

public class HotelInfo extends HotelPO {

	public HotelInfo(String n, String a, HotelTradeArea t, String i, String s, HotelRanking r) {
		super(n, a, t, i, s, r);
		// TODO Auto-generated constructor stub
	}

}
