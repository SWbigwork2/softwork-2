package promotionsblimpl;

import Roomblimpl.RoomsInfo;

public interface PromotionGetPrice {
	public PriceInfo getPrice(String hotel,double price,int roomNum,String userId,int days);
	
}