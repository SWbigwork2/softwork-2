package promotionsblimpl;

public enum ResultMessage {
	   Success,Failure,hasexistpromotion
	}

