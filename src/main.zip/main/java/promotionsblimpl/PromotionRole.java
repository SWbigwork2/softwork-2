package promotionsblimpl;

public enum PromotionRole {
   hotelworker,webworker
}
