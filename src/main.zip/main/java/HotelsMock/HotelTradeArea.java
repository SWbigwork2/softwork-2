package HotelsMock;

public enum HotelTradeArea {
	栖霞区,江宁区,鼓楼区
}
