package view.marketer;

public class PromotionsvController  {

}
