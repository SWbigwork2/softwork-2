package view.marketer;

import javafx.fxml.FXML;

public class Promotionsii2Controller {
    
	
	
}
