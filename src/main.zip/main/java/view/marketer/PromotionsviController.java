package view.marketer;

public class PromotionsviController  {

	
}
