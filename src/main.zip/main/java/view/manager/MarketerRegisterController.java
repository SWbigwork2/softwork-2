package view.manager;

import javafx.fxml.FXML;

/**
 * @author lenovo
 *
 */
public class MarketerRegisterController {
    
	
	/**
	 * MarketerRegister���ذ�ť�ļ���
	 */
	@FXML
	public void cancel(){
		
	}
	
	/**
	 * MarketerRegisterȷ�ϰ�ť�ļ���
	 */
	@FXML
	public void confirm(){
		
	}
}
