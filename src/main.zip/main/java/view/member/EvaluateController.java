package view.member;

import javafx.fxml.FXML;

public class EvaluateController {
    
	@FXML
	private void cancel(){
		
	}
	
	@FXML
	private void confirm(){
		
	}
}
