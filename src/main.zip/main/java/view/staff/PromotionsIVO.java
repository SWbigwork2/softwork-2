package view.staff;

public class PromotionsIVO extends PromotionsVO {

    public PromotionsIVO(int type,String hotel,String introduction,double discount){
    	super(type, hotel, introduction, discount);
    }
}
