package EvaluateMock;

import java.util.Date;

import RoomsMock.RoomType;
import ordersblimpl.OrderType;
import po.OrderPO;

public class OrdersInfo extends OrderPO{

	public OrdersInfo(int orderId, String userId, String userNameString, String hotelNameString, RoomType roomType,
			int roomNum, double price, OrderType orderType, Date inDate, Date outDate, Date completeDate,
			Date revokeDate, Date deadLine,int peopleNum, Date beginDate) {
		super(orderId, userId, hotelNameString, roomType, roomNum, price, orderType, inDate, outDate,
				completeDate, revokeDate, deadLine,peopleNum,beginDate);
		// TODO Auto-generated constructor stub
	}

}
