package EvaluateMock;

import po.MemberPO;

public class MemberInfo extends MemberPO{

	public MemberInfo(String i, String n, String p, String t, double c) {
		super(i, n, p, t, c);
		// TODO Auto-generated constructor stub
	}

}
