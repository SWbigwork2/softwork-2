package ordersblimpl;

public enum ResultMessage {
	success,fail,notEnough,userNotExist,hotelNotExist,orderNotExist

}
