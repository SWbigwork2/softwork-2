package UsersMock;

public interface UserInfo {
	 public UserVO find(String  id,UserType type);
	
}
