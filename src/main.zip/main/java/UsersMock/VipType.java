package UsersMock;

public enum VipType {
    ConmmentVip,CompanyVip
}
