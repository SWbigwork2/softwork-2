package UsersMock;

public enum ResultMessage {
    success,fail,userNotFound,userHadExisted
}
