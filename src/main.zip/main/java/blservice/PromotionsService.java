package blservice;

public interface PromotionsService {

}
