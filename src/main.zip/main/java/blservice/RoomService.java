package blservice;

public interface RoomService {

}
