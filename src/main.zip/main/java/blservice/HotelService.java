package blservice;

public interface HotelService {

}
