package po;

import UsersMock.UserType;

public class MarketerPO extends UserPO{

	public MarketerPO(String i, String n, String p) {
		super(i, n, p, UserType.marketer);
		// TODO Auto-generated constructor stub
	}
    
}
