package po;

import UsersMock.UserType;

public class ManagerPO extends UserPO{

	public ManagerPO(String i, String n, String p) {
		super(i, n, p, UserType.manager);
		// TODO Auto-generated constructor stub
	}

}
