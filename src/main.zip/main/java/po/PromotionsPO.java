package po;

public class PromotionsPO {
int type;
String hotel;
double discount;
String introduction;
public int getType(){
	return type;
}
public String getHotel(){
	return hotel;
}
public double getDiscount(){
	return discount;
}
public String getIntroduction(){
	return introduction;
}
}
