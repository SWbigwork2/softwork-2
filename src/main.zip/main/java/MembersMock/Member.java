package MembersMock;

import java.util.ArrayList;

import ordersblimpl.OrderItem;
import ordersblimpl.OrderVO;

public abstract class Member {
     public abstract ArrayList<OrderVO>  getOrder(String id);
     public abstract ArrayList<String> getHotel(String id);
}
