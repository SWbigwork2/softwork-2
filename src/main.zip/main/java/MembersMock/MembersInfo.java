package MembersMock;

public interface MembersInfo {
	public double getCredit();
	public String getName();
	public String getID();
	public String getPassword();
	 public String getTelephone();

}
