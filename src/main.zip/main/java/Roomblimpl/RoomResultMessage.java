package Roomblimpl;

public enum RoomResultMessage {
	success,failue;

}
