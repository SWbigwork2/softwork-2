package Roomblimpl;

public enum RoomType {
	单人间,标准间,商务间,行政标准间,高级套间;
}
