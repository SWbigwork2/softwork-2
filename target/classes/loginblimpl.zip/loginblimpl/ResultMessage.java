package loginblimpl;

public enum ResultMessage {
	success,userNotExit,passwordError
}
