package ordersblimpl;

public enum OrderType {
	normal,revoke,done,error,all,appeal,evaluation

}
