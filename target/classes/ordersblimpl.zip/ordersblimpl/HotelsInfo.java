package ordersblimpl;

import Hotelblimpl.HotelRanking;
import Hotelblimpl.HotelTradeArea;
import po.HotelPO;

public class HotelsInfo extends HotelPO{

	public HotelsInfo(String n, String a, HotelTradeArea t, String i, String s, HotelRanking r) {
		super(n, a, t, i, s, r);
		// TODO Auto-generated constructor stub
	}

}
