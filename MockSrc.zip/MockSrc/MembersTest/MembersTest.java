package MembersTest;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Date;

import org.junit.Test;

import HotelsMock.HotelPO;
import HotelsMock.HotelRanking;
import HotelsMock.HotelTradeArea;
import HotelsMock.HotelsInfo;
import MembersMock.MemberControllerMock;
import MembersMock.MemberPO;
import MembersMock.MembersInfo;
import MembersMock.ResultMessage;
import OrdersMock.OrdersMock;
import PromotionsMock.Promotions;
import RoomsMock.RoomPO;
import RoomsMock.RoomType;
import RoomsMock.RoomsInfo;
public class MembersTest {
Date date = new Date(2016, 11,1);
	
	RoomsInfo rI = new RoomPO("0001", "�ʳ�", RoomType.big, "", 100, new int[3]);
	MembersInfo mI = new MemberPO("0001", "admin","admin","10086", 300);
	HotelsInfo hI = new HotelPO("�ʳ�", "���ִ��103",HotelTradeArea.��ϼ��, "", "", HotelRanking.oneStar);
	Promotions po = new Promotions();
	String memberId="admin";
    String memberPassword="123456";
    String memberName="С��";
    String memberTelephone="8888";
    double credit=100;
    @Test
	public void Addmembertest() {
    	MemberControllerMock membercontrollerMock =new MemberControllerMock(new OrdersMock());
    	
    	assertEquals(membercontrollerMock.addmember(memberId, memberPassword,memberName, memberTelephone),ResultMessage.Success);
    	assertEquals(membercontrollerMock.addmember(memberId, memberPassword,memberName, memberTelephone),ResultMessage.Failure);
		
		
	}
    @Test
    public void getHotelTest(){
    	String id="admin";
    	OrdersMock om=new OrdersMock();
    	
    	MemberControllerMock mcm=new MemberControllerMock(om);
    	ArrayList<String> s2=om.getHistoyHotel(id);
    	ArrayList<String> s1=mcm.getHotel(id);
    	
    	assertEquals(s1,s2);   	
    }
    @Test
    public void getOrderTest(){
    	String id="admin";
    	OrdersMock om=new OrdersMock();
    	MemberControllerMock mcm=new MemberControllerMock(om);
    	assertEquals(mcm.getOrder(id),om.getOrderHistory(id, null));   	
    }
}
