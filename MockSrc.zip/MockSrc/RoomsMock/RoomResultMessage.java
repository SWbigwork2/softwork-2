package RoomsMock;

public enum RoomResultMessage {
	success,failue;

}
