package EvaluateMock;

public enum ResultMessage {
    success,fail
}
