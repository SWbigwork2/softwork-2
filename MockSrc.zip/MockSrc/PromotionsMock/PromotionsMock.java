package PromotionsMock;

public class PromotionsMock extends Promotions{
         
}
