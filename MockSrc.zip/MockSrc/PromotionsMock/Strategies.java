package PromotionsMock;

public class Strategies {
String hotel;
double discount;
String introduction;
public String getHotel(){
	return hotel;
}
public double getDiscount(){
	return discount;
}
public String getIntroduction(){
	return introduction;
}
}
