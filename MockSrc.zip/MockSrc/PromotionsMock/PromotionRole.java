package PromotionsMock;

public enum PromotionRole {
   hotelworker,webworker
}
