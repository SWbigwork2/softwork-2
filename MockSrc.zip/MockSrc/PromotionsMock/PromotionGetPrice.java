package PromotionsMock;

import RoomsMock.RoomsInfo;

public interface PromotionGetPrice {
	public double getPrice(RoomsInfo info,int num);
}