package UsersMock;

public enum UserType {
	manager,marketer,staff,member
}
