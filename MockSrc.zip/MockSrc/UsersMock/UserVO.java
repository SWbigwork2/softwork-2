package UsersMock;

import java.sql.Date;

public  abstract class UserVO {
    String userId;
    String password;
    String name;
    UserType type;
}
