package MembersMock;

public enum ResultMessage {
	   Success,Failure,Memberhasexist
	}
