package HotelsMock;

public class Hotel {

}
