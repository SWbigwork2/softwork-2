package HotelsMock;

public enum ResultMessage {
	success,failure;

}
