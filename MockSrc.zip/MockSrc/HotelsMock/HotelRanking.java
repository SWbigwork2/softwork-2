package HotelsMock;

public enum HotelRanking {
	oneStar,twoStar,threeStar,fourStar,FiveStar;
}
