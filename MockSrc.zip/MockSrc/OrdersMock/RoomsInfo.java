package OrdersMock;

import RoomsMock.RoomPO;
import RoomsMock.RoomType;

public class RoomsInfo extends RoomPO{

	public RoomsInfo(String r, String h, RoomType t, String i, double p, int[] s) {
		super(r, h, t, i, p, s);
		// TODO Auto-generated constructor stub
	}
	
}
