package OrdersMock;

public class MembersInfo {
	int memberId;
	String name;
	double credit;
	public MembersInfo(int memberId, String name, double credit) {
		this.memberId = memberId;
		this.name = name;
		this.credit = credit;
	}
	
}
