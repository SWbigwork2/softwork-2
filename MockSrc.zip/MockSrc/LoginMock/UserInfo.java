package LoginMock;

import java.util.ArrayList;
import java.util.Date;
import UsersMock.UserPO;
import UsersMock.UserType;

public class UserInfo extends UserPO{

	public UserInfo(String i, String n, String p, UserType r, String hotel,Date birthday) {
		super(i, n, p, r, hotel,birthday);
		// TODO Auto-generated constructor stub
	}
	

}
