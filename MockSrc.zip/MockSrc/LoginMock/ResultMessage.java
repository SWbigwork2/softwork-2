package LoginMock;

public enum ResultMessage {
	success,userNotExit,passwordError
}
